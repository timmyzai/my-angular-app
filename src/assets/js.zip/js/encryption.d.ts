declare module 'src/assets/js/encryption.js' {
    export function encryptWithPemPKCS(message: string, publicKeyPem: string): Promise<string>;
    export function encryptWithPemSHA256(message: string, publicKeyPem: string): Promise<string>;
}
