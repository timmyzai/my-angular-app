const forge = require('node-forge');

async function encryptWithPemPKCS(message, publicKeyPem) {
    try {
        const publicKey = forge.pki.publicKeyFromPem(publicKeyPem);
        if (publicKey && typeof publicKey.encrypt === 'function') {
            const encryptedBytes = publicKey.encrypt(message, 'RSAES-PKCS1-V1_5');
            const encryptedBase64 = forge.util.encode64(encryptedBytes);

            return encryptedBase64;
        } else {
            console.error('Invalid or unsupported public key format');
            throw new Error('Invalid or unsupported public key format.');
        }
    } catch (e) {
        console.error('Encryption error:', e);
        throw new Error('Encryption failed. Please verify your input.');
    }
}
async function encryptWithPemSHA256(message, publicKeyPem) {
    try {
        const publicKey = forge.pki.publicKeyFromPem(publicKeyPem);
        if (publicKey && typeof publicKey.encrypt === 'function') {
            const md = forge.md.sha256.create();
            const keySizeBytes = publicKey.n.bitLength() / 8;
            const maxMessageLength = keySizeBytes - 2 * md.digestLength - 2; // Adjust for padding

            const chunks = [];
            for (let i = 0; i < message.length; i += maxMessageLength) {
                const chunk = message.substring(i, i + maxMessageLength);
                const encryptedBytes = publicKey.encrypt(chunk, 'RSA-OAEP', {
                    md: md,
                    mgf1: { md: md }
                });
                chunks.push(encryptedBytes);
            }

            const encryptedData = chunks.reduce((acc, chunk) => acc + chunk, '');
            return forge.util.encode64(encryptedData);
        } else {
            console.error('Invalid or unsupported public key format');
            throw new Error('Invalid or unsupported public key format.');
        }
    } catch (e) {
        console.error('Encryption error:', e);
        throw new Error('Encryption failed. Please verify your input.');
    }
}

module.exports = { encryptWithPemPKCS, encryptWithPemSHA256 };
